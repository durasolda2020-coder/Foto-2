# FotoCard – versão PWA

Esta pasta contém uma versão instalável do FotoCard para Android/Samsung.

Ficheiros:
- index.html — aplicação original
- manifest.webmanifest — configuração de instalação
- sw.js — funcionamento offline/cache
- icon-192.png / icon-512.png — ícones

## Instalação no telemóvel
1. Coloque estes ficheiros num alojamento HTTPS de ficheiros estáticos (por exemplo GitHub Pages).
2. Abra o endereço no Chrome do Samsung.
3. Dê permissão à câmara quando solicitado.
4. No menu do Chrome escolha "Adicionar ao ecrã principal" / "Instalar aplicação".
5. O FotoCard passa a abrir como uma aplicação.

Nota: a câmara do navegador normalmente exige HTTPS (ou localhost). Abrir o index.html diretamente como ficheiro não é uma forma fiável de usar a câmara.
